const express = require("express");
const app = express();
const uuid = require("uuid");
const PORT = 3000;
const cors =require("cors");

app.use(express.json());
app.use(cors());


const activities = [
    {
        id: 1,
        name: "Beterna task",
        description: "Create a app",
        completed: false,
        timestamp: Date()
    },

    {
        id: 2,
        name: "AIPS task",
        description: "Kviz",
        completed: false,
        timestamp: Date().toString()
    }
];


app.get("/", (req,res) =>{
    res.json({msg: "To do list"});
});

app.get("/activities", (req,res) => {
    res.json(activities);
})

app.get("/activities/:id", (req,res) => {
    let activity = activities.filter((activity) => activity.id == req.params.id);
    res.json({msg: "1 Activity", data: activity});
});

app.post("/activities", (req,res) => {
    activities.push({id: uuid.v4(), ...req.body, timestamp: Date()});
    res.json({msg: "Add", data: activities});
});

app.put("/activities/:id", (req,res) => {
    let activity = activities.find((activity) => activity.id == req.params.id );
    if(activity){
        activity.name = req.body.name;
        activity.description = req.body.description;
        activity.completed = req.body.completed;
        activity.timestamp = Date();
        res.json({msg: "Edit", data: activities});
    }
    else {
        res.json({msg: "Activity does not exist"});

    }
});

app.delete("/activities/:id", (req,res) => {
    let index = activities.findIndex(activity => activity.id == req.params.id);
    activities.splice(index,1);
    res.json({msg: "Delete", data:activities});
});

app.listen(PORT, () =>{
    console.log(`App is running on PORT ${PORT}`);
});