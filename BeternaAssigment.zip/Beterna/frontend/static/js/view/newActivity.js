import abstractView from "./abstractView.js";
const appURL = "http://localhost:3000/activities"

export default class extends abstractView{
    constructor() {
        super();
        this.setTitle("New Activity");
    }
    async getHtml(){

        return`
        
        <h1>Add new activity</h1>
        <body>
        <form id="submitForm" method="GET">
            <div class = button-div>
                <button class="button" type="submit" id="add" role="button">Add</button>
            </div>
            <div class="row">
                <input type="text" id="activity_name" placeholder="Activity Name"  required>        
            </div>
            <div class="row">
                <textarea id="activity_description" placeholder="Activity Description" required></textarea>
            </div>
            <div class="checkbox-wrapper">
                <input type="checkbox" id="_checkbox">
                <label for="_checkbox">
                    <div class="tick_mark"></div>
                </label>  
            </div>
        </form>
  
</body>
        
        `;

    }

}

export async function addActivity() {
    try {
        const activityName = document.getElementById("activity_name");
        const activityDescription = document.getElementById("activity_description");
        const activityCompleted = document.getElementById("_checkbox");
        let options = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                name: activityName.value,
                description: activityDescription.value,
                completed: activityCompleted.checked,
            }),
        };
        const resp = await fetch(appURL, options);
        activityName.value = "";
        activityDescription.value = "";
        activityCompleted.checked = false;
        return await resp.json();
    } catch (err) {
        return err;
    }

}

