export default class {
    constructor() {
    }

    setTitle(title){
        document.title = title;
    }

    getTitle(){
        return document.title;
    }

    async getHtml(){
        return ``;
    }

}