import abstractView from "./abstractView.js";
const appURL = "http://localhost:3000/activities"
let activities = [];
export default class extends abstractView{
    constructor() {
        super();
        this.setTitle("List Activity");
    }

    async getHtml(){
        return`
        <h1>Activities</h1>
        <body>
        <div class="activities-container">
        
<!--        This thing is done in the function displayActivities()-->
<!--            <div class="activities">-->
<!--                <div class="row">-->
<!--                    <p class="activityName">Beterna Task</p>-->
<!--                    <form class="activityButtons">-->
<!--                        <button class="activity" id="Edit" style="margin-right: 10px;">Edit</button>-->
<!--                        <button class="activity" id="Delete">Delete</button>-->
<!--                    </form>-->
<!--                </div>-->
<!--            </div>-->
            
            
        </div>
        <div class="modal-background" id="editConfirmation">
            <div class="modal">
                <div class="modal-top">
                    <h1>Edit Activity</h1>
                    <span class="close-modal" id="close-modal">&#x2715;</span>
                </div>
                <div class="modal-bottom">
                    <input type="text" id="edit_name" placeholder="New Name">
                    <textarea id="edit_description" placeholder="New Description"></textarea>
                    <div class="checkbox-wrapper">
                        <input type="checkbox" id="_checkbox">
                        <label for="_checkbox">
                            <div class="tick_mark"></div>
                        </label>  
                    </div>
                    <button class="button" id="save-edit" data-link="/list">Save</button>
                </div>
            </div>
        </div>
        
        <div class="modal-background" id="deleteConfirmation">
            <div class="modal" id="deleteModal">
                <div class="modal-bottom">
                    <label class="row" id="question">Are you sure you want to delete this activity?</label>
                    <div class="row" id="conDelButt">
                        <button class="button" id="delete" data-link="/list">Delete</button>
                        <button class="button" id="cancel">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
</body>
`;
    }
}

async function getActivities() {
    try{
        const resp = await fetch(appURL);
        return await resp.json();
    }
    catch (err){
        return err;
    }
}

export function list(){
    getActivities()
        .then(activitiesArr => {
            activities = activitiesArr;
            displayActivities(activities);
        }).catch((err) => console.log(err));
}

function displayActivities(array){
    array.forEach((actElement) => {
        const activityContainer = document.querySelector(".activities-container")
        //First <div> class = "activities"
        let activities = document.createElement("div");
        activities.classList.add("activities");

        //Second <div> class= "row"
        let row = document.createElement("div");
        row.classList.add("row");

        //Inside the second <div> class="row" we have...
        let activityName = document.createElement("p");
        activityName.classList.add("activityName");
        activityName.innerHTML = actElement.name;


        let timeCreated = document.createElement("p");
        timeCreated.innerHTML = new Date(actElement.timestamp).toLocaleString();
        timeCreated.id = "timestampID";

        let activityButtons = document.createElement("form");
        activityButtons.classList.add("activityButtons");

        //Inside the form we have two buttons...
        let editButton = document.createElement("button");
        editButton.classList.add("activity");
        editButton.innerHTML = "Edit";
        editButton.style.marginRight = "10px";
        editButton.addEventListener("click", e => {
            e.preventDefault();
            openModalEdit(actElement);
        })
        let deleteButton = document.createElement("button");
        deleteButton.classList.add("activity");
        deleteButton.innerHTML = "Delete";
        deleteButton.addEventListener("click",  e => {
            e.preventDefault();
            openModalDelete(actElement);
        })

        //We combined the all in the activity-container
        row.appendChild(activityName);
        row.appendChild(timeCreated)
        row.appendChild(activityButtons);
        activityButtons.appendChild(editButton); //we put the first button in the form
        activityButtons.appendChild(deleteButton);//we put the second button in the form
        activities.appendChild(row);// combined them
        activityContainer.appendChild(activities);//add them to the container
    });

}

async function activityDelete(element){
    try{
        const deleteURL = appURL + "/" + element.id;
        const options = {
            method: "DELETE",
        };
        const resp = await fetch(deleteURL,options);
        return await resp.json();
    }
    catch (err){
        return err;
    }
}

async function editActivity(Id, newName, newDescription, newTime) {
    try {
        let editURL = appURL + "/" + Id;
        let options = {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: Id,
                name: newName,
                description: newDescription,
                completed: newTime,
            }),
        };
        const resp = await fetch(editURL, options);

        return await resp.json();
    } catch (err) {
        return err;
    }

}

function openModalDelete(element){
    const modalBG = document.getElementById("deleteConfirmation");
    const deleteButton = document.getElementById("delete");
    const cancelButton = document.getElementById("cancel");
    modalBG.style.display = "block";
    deleteButton.addEventListener("click", () =>{
        modalBG.style.display = "none";
        activityDelete(element);
    });

    cancelButton.addEventListener("click", () =>{
        modalBG.style.display = "none";
    });

}

function openModalEdit(element){
    const modalBG = document.getElementById("editConfirmation");
    const closeModal = document.querySelector(".close-modal");
    const editName = document.getElementById("edit_name");
    const editDescription = document.getElementById("edit_description");
    const editCompleted = document.getElementById("_checkbox");
    const saveEdit = document.getElementById("save-edit");

    editName.value = element.name;
    editDescription.value = element.description;
    editCompleted.checked = element.completed;
    modalBG.style.display = "block";
    closeModal.addEventListener("click", () =>{
        modalBG.style.display = "none";
    });
    saveEdit.addEventListener("click", () =>{
        modalBG.style.display = "none";
        editActivity(element.id,editName.value,editDescription.value,editCompleted.checked,Date());
    });

}

