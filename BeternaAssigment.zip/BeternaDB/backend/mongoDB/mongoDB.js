const express = require("express");
const mongoose = require("mongoose");
const {connect, mongo} = require("mongoose");
const {json} = require("express");
const cors = require("cors");
const uuid = require("uuid");

const PORT = 3000;
const connectionString = "mongodb+srv://klims7405:DwSiZcuVBDhGFjgE@cluster0.u39tbkd.mongodb.net/Activities?retryWrites=true&w=majority&appName=Cluster0";


const app = express();
app.use(express.json());
app.use(cors());

const activitySchema = new mongoose.Schema({
    name: String,
    description: String,
    completed: Boolean,
    timestamp: String,
})

const activitiesModel = mongoose.model("activitiesModel", activitySchema);

app.get("/", (req,res) => {
    res.send("Hey yo");
});

app.get("/activities", async (req,res) => {
    const activities = await activitiesModel.find({});
    res.json(activities)
});

app.get("/activities/:id", async (req, res) => {
    const activity = await activitiesModel.findById(req.params.id);
    res.json(activity);
});

app.post("/activities", async (req, res) => {
    const activity = await activitiesModel.create({...req.body, timestamp: Date()});
    res.json(activity);
});

app.put("/activities/:id", async (req, res) => {
    const activity = await activitiesModel.findByIdAndUpdate(req.params.id,{...req.body,timestamp: Date()});
    res.json(activity);
});

app.delete("/activities/:id", async (req, res) => {
    const activity = await activitiesModel.findByIdAndDelete(req.params.id);
    res.json(activity);
});

function connectDB(url){
    return mongoose.connect(url)
}
async function start(){
    try{
        await connectDB(connectionString);
        app.listen(PORT, () =>{
            console.log(`App running on ${PORT}`);
        });
    } catch (err){
        console.log(err);
    }
}

start();
// DwSiZcuVBDhGFjgE

